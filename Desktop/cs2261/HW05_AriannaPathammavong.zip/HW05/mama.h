
//{{BLOCK(mama)

//======================================================================
//
//	mama, 20x30@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 600 = 1112
//
//	Time-stamp: 2018-10-16, 00:34:36
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MAMA_H
#define GRIT_MAMA_H

#define mamaBitmapLen 600
extern const unsigned short mamaBitmap[300];

#define mamaPalLen 512
extern const unsigned short mamaPal[256];

#endif // GRIT_MAMA_H

//}}BLOCK(mama)
