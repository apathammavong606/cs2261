
//{{BLOCK(mamaAngry)

//======================================================================
//
//	mamaAngry, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2018-10-14, 21:56:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MAMAANGRY_H
#define GRIT_MAMAANGRY_H

#define mamaAngryBitmapLen 38400
extern const unsigned short mamaAngryBitmap[19200];

#define mamaAngryPalLen 512
extern const unsigned short mamaAngryPal[256];

#endif // GRIT_MAMAANGRY_H

//}}BLOCK(mamaAngry)
