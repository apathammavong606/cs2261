
//{{BLOCK(spriteSheet)

//======================================================================
//
//	spriteSheet, 448x968@4, 
//	+ palette 256 entries, not compressed
//	+ 6776 tiles not compressed
//	Total size: 512 + 216832 = 217344
//
//	Time-stamp: 2018-11-13, 01:31:12
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPRITESHEET_H
#define GRIT_SPRITESHEET_H

#define spriteSheetTilesLen 216832
extern const unsigned short spriteSheetTiles[108416];

#define spriteSheetPalLen 512
extern const unsigned short spriteSheetPal[256];

#endif // GRIT_SPRITESHEET_H

//}}BLOCK(spriteSheet)
